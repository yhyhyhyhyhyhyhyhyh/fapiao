"""Integration tests. Run: DB_ENGINE=sqlite DJANGO_DEBUG=1 python manage.py test invoices"""
from datetime import date
from io import BytesIO
from unittest.mock import patch
from zipfile import ZipFile
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from .models import Activity, Folder, InvoiceFile, User, Week
from .services import current_monday, safe_relative_path, validate_name

PDF = b'%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF\n'


class InvoiceTestBase(TestCase):
    def setUp(self):
        self.admin1 = User.objects.create_user(username='teacher', display_name='老师',
            password='ComplexPass#1234', role=User.Role.ADMIN, must_change_password=False, is_staff=True)
        self.admin2 = User.objects.create_user(username='manager', display_name='负责人',
            password='ComplexPass#1234', role=User.Role.ADMIN, must_change_password=False, is_staff=True)
        self.alice = User.objects.create_user(username='alice', display_name='张三',
            password='ComplexPass#1234', role=User.Role.MEMBER, must_change_password=False)
        self.bob = User.objects.create_user(username='bob', display_name='李四',
            password='ComplexPass#1234', role=User.Role.MEMBER, must_change_password=False)
        self.week = Week.objects.create(start_date=date(2026, 10, 26))

    def login_as(self, user):
        self.client.force_login(user)

    def uploaded(self, name='receipt.pdf'):
        return SimpleUploadedFile(name, PDF, content_type='application/pdf')


class AccessTests(InvoiceTestBase):
    def test_anonymous_redirects_to_login(self):
        response = self.client.get(reverse('week_detail', args=[self.week.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)

    def test_member_cannot_browse_other_member(self):
        self.login_as(self.alice)
        response = self.client.get(reverse('browse', args=[self.week.pk, self.bob.pk]))
        self.assertEqual(response.status_code, 403)

    def test_member_cannot_manage_accounts(self):
        self.login_as(self.alice)
        self.assertEqual(self.client.get(reverse('member_list')).status_code, 403)
        self.assertEqual(self.client.post(reverse('archive', args=[self.week.pk])).status_code, 403)

    def test_two_equal_admins_can_archive_and_reopen(self):
        self.login_as(self.admin1)
        self.client.post(reverse('archive', args=[self.week.pk]))
        self.week.refresh_from_db()
        self.assertTrue(self.week.is_archived)
        self.login_as(self.admin2)
        self.client.post(reverse('archive', args=[self.week.pk]))
        self.week.refresh_from_db()
        self.assertFalse(self.week.is_archived)

    def test_first_login_requires_password_change(self):
        self.alice.must_change_password = True
        self.alice.save()
        self.login_as(self.alice)
        response = self.client.get(reverse('week_list'))
        self.assertRedirects(response, reverse('change_password'))

    def test_admin_password_reset_member_only(self):
        self.login_as(self.admin2)
        response = self.client.post(reverse('member_password', args=[self.alice.pk]), {
            'password1': 'NewStrongPass#987', 'password2': 'NewStrongPass#987'})
        self.assertEqual(response.status_code, 302)
        self.alice.refresh_from_db()
        self.assertTrue(self.alice.check_password('NewStrongPass#987'))
        self.assertTrue(self.alice.must_change_password)
        self.assertEqual(self.client.get(reverse('member_password', args=[self.admin1.pk])).status_code, 404)


class FileTests(InvoiceTestBase):
    def test_member_upload_and_private_download(self):
        self.login_as(self.alice)
        url = reverse('upload', args=[self.week.pk])
        resp = self.client.post(url, {'files': [self.uploaded()]})
        self.assertEqual(resp.status_code, 302)
        stored = InvoiceFile.objects.get(owner=self.alice)
        self.assertEqual(stored.name, 'receipt.pdf')
        self.assertTrue(stored.blob.name.startswith('invoices/'))
        self.login_as(self.bob)
        self.assertEqual(self.client.get(reverse('download_file', args=[stored.pk])).status_code, 403)
        self.login_as(self.admin1)
        self.assertEqual(self.client.get(reverse('download_file', args=[stored.pk])).status_code, 200)

    def test_upload_preserves_nested_directory(self):
        self.login_as(self.alice)
        resp = self.client.post(reverse('upload', args=[self.week.pk]), {
            'folder_files': [self.uploaded('invoice.pdf')],
            'paths': ['顺丰/运单/invoice.pdf'],
        })
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(Folder.objects.filter(owner=self.alice).count(), 2)
        self.assertEqual(InvoiceFile.objects.get().folder.name, '运单')

    def test_archive_prevents_member_modification(self):
        self.week.is_archived = True
        self.week.save()
        self.login_as(self.alice)
        resp = self.client.post(reverse('upload', args=[self.week.pk]), {'files': [self.uploaded()]})
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(InvoiceFile.objects.count(), 0)

    def test_invalid_file_extension_rejected(self):
        self.login_as(self.alice)
        resp = self.client.post(reverse('upload', args=[self.week.pk]), {
            'files': [SimpleUploadedFile('evil.html', b'<script>xx</script>')]})
        self.assertEqual(resp.status_code, 302)
        self.assertEqual(InvoiceFile.objects.count(), 0)

    def test_zip_contains_member_folder_and_nested_files(self):
        folder = Folder.objects.create(week=self.week, owner=self.alice, name='顺丰')
        f = InvoiceFile.objects.create(week=self.week, owner=self.alice, name='运单.pdf', folder=folder,
                                       blob=self.uploaded('waybill.pdf'), size=len(PDF))
        self.login_as(self.admin2)
        resp = self.client.get(reverse('download_week_zip', args=[self.week.pk]))
        self.assertEqual(resp.status_code, 200)
        raw = b''.join(resp.streaming_content)
        with ZipFile(BytesIO(raw)) as zf:
            self.assertIn('张三发票/顺丰/运单.pdf', zf.namelist())
            self.assertIn('李四发票/', zf.namelist())

    def test_trash_hides_nested_files_and_restores(self):
        folder = Folder.objects.create(week=self.week, owner=self.alice, name='快递')
        f = InvoiceFile.objects.create(week=self.week, owner=self.alice, folder=folder,
            name='运单.pdf', blob=self.uploaded(), size=len(PDF))
        self.login_as(self.alice)
        self.client.post(reverse('delete_item', args=[self.week.pk]), {'kind':'folder','id':folder.pk})
        self.assertEqual(self.client.get(reverse('download_file', args=[f.pk])).status_code, 404)
        self.client.post(reverse('restore_item', args=[self.week.pk]), {'kind':'folder','id':folder.pk})
        self.assertEqual(self.client.get(reverse('download_file', args=[f.pk])).status_code, 200)

    def test_folder_cannot_move_into_self(self):
        folder = Folder.objects.create(week=self.week, owner=self.alice, name='A')
        child = Folder.objects.create(week=self.week, owner=self.alice, name='B', parent=folder)
        self.login_as(self.alice)
        self.client.post(reverse('move_item', args=[self.week.pk]), {
            'kind': 'folder', 'id': folder.pk, 'destination': child.pk})
        folder.refresh_from_db()
        self.assertIsNone(folder.parent_id)

    def test_path_traversal_rejected(self):
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            safe_relative_path('../private/receipt.pdf')
        with self.assertRaises(ValidationError):
            validate_name('../bad')


class MemberManagementTests(InvoiceTestBase):
    def test_create_member_and_disable_preserves_data(self):
        self.login_as(self.admin1)
        response = self.client.post(reverse('member_add'), {
            'username': 'charlie', 'display_name': '小陈',
            'password1': 'ComplexPass#9999', 'password2': 'ComplexPass#9999'})
        self.assertRedirects(response, reverse('member_list'))
        charlie = User.objects.get(username='charlie')
        self.assertFalse(charlie.is_lab_admin)
        self.assertTrue(charlie.must_change_password)
        self.client.post(reverse('member_toggle', args=[charlie.pk]))
        charlie.refresh_from_db()
        self.assertFalse(charlie.is_active)
        self.assertTrue(User.objects.filter(username='charlie').exists())
