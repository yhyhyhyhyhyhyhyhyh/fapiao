import uuid
from datetime import timedelta
from pathlib import Path
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = 'admin', '管理员'
        MEMBER = 'member', '成员'

    role = models.CharField(max_length=10, choices=Role.choices, default=Role.MEMBER)
    display_name = models.CharField('姓名', max_length=60)
    must_change_password = models.BooleanField(default=True)

    @property
    def is_lab_admin(self):
        return self.role == self.Role.ADMIN and self.is_active

    @property
    def shown_name(self):
        return self.display_name or self.username

    def __str__(self):
        return f'{self.shown_name} ({self.username})'


class Week(models.Model):
    start_date = models.DateField(unique=True)
    is_archived = models.BooleanField(default=False)
    archived_at = models.DateTimeField(null=True, blank=True)
    archived_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                    on_delete=models.SET_NULL, related_name='weeks_archived')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-start_date']

    @property
    def end_date(self):
        return self.start_date + timedelta(days=6)

    @property
    def label(self):
        iso_year, iso_week, _ = self.start_date.isocalendar()
        return f'{iso_year}年第{iso_week:02d}周'

    @property
    def range_label(self):
        return f'{self.start_date:%Y.%m.%d}—{self.end_date:%m.%d}'

    def __str__(self):
        return self.label


def file_storage_path(instance, filename):
    # The original name stays in the database; disk names are random and private.
    suffix = Path(filename).suffix.lower()
    return f'invoices/{instance.week_id}/{instance.owner_id}/{uuid.uuid4().hex}{suffix}'


class Folder(models.Model):
    week = models.ForeignKey(Week, on_delete=models.PROTECT, related_name='folders')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='invoice_folders')
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.PROTECT, related_name='children')
    name = models.CharField(max_length=160)
    trashed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [models.Index(fields=['week', 'owner', 'parent'])]
        ordering = ['name', 'id']

    def __str__(self):
        return self.name


class InvoiceFile(models.Model):
    week = models.ForeignKey(Week, on_delete=models.PROTECT, related_name='invoice_files')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='invoice_files')
    folder = models.ForeignKey(Folder, null=True, blank=True, on_delete=models.PROTECT, related_name='invoice_files')
    name = models.CharField(max_length=160)
    blob = models.FileField(upload_to=file_storage_path, max_length=360)
    size = models.BigIntegerField(default=0)
    content_type = models.CharField(max_length=120, blank=True)
    trashed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [models.Index(fields=['week', 'owner', 'folder'])]
        ordering = ['name', 'id']

    def __str__(self):
        return self.name


class Activity(models.Model):
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name='actions')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name='invoice_history')
    week = models.ForeignKey(Week, null=True, on_delete=models.SET_NULL, related_name='activities')
    action = models.CharField(max_length=32)
    description = models.CharField(max_length=300)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ['-created_at', '-id']
        indexes = [models.Index(fields=['owner', 'week', 'created_at'])]


class LoginAttempt(models.Model):
    username = models.CharField(max_length=150)
    client_ip = models.CharField(max_length=50)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [models.Index(fields=['username', 'client_ip', 'created_at'])]
