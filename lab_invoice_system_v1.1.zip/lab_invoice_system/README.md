# 实验室发票上传与归档管理系统（Lab Invoice）

**版本：V1.0（可自行部署的源代码项目）** · 中文界面 · PC/手机浏览器 · 自有云服务器

这是一套专门为课题组开发的按周发票收集系统，而非需要外部 SaaS 账号的网盘。管理员可以按“周次 → 张三发票 → 子文件夹/文件”查看、归档或打包下载；成员只能管理自己的资料。

## 1. 系统实现范围

- **两个同权限管理员**：部署初始化时创建；可查看任何成员文件、每周情况、打包 ZIP、手动归档和重新开放、创建/停用成员、重置成员密码。管理界面不开放第三个管理员入口。
- **成员账号**：管理员设置姓名、登录账号和初始密码；首次登录强制修改密码；无公开自助注册功能。
- **每周收集**：按郑州大学2026—2027学年校历显示秋季、春季学期及假期周次（2026-09-07为秋季第1周、2026-10-26为第8周）；北京时间周一至周日为归档周期；访问首页自动创建当周记录；历史周次可补传；管理员手动归档。
- **成员文件**：多文件上传、选择整个文件夹（Chrome、Edge、Safari 等支持此能力的浏览器）、自动保留目录层级、建文件夹、改名、移动、删除到回收站、恢复、预览/下载。
- **管理员文件**：成员顶层虚拟目录自动显示“姓名发票”，可展开多级文件夹；支持按成员 ZIP 下载和全周 ZIP 下载；汇总本周已上传/未上传人数。
- **历史**：周次列表 + 个人/管理员操作流水，含上传、移动、重命名、删除、恢复、账号操作与归档。
- **不包含**：报销审批、发票真伪验证、OCR自动识别、微信/邮件自动通知、资金金额核算。

## 2. 首次部署（推荐：Ubuntu 云服务器 + Docker Compose）

**前提条件**：64位 Ubuntu 22.04/24.04；已安装 Docker Engine 和 Docker Compose Plugin；云服务商安全组放通 TCP 80、443；有域名更适合正式使用。服务器建议 **2核 CPU / 2—4GB内存 / 40GB以上磁盘**（实际空间取决于发票数量、备份大小）。

将项目目录上传到服务器，例如 `/opt/lab_invoice_system`：

```bash
cd /opt/lab_invoice_system
cp .env.example .env
chmod 600 .env
```

使用以下命令分别生成**不同的随机字符串**，粘贴到 `.env` 对应字段（不要使用示例占位符）：

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

编辑 `.env`，至少设置：

| 配置 | 说明 |
| --- | --- |
| `DJANGO_SECRET_KEY` | 生成的随机密钥，切勿更换后丢失现有会话 |
| `POSTGRES_PASSWORD` | 独立的强数据库密码 |
| `ADMIN1_USERNAME` / `ADMIN1_NAME` / `ADMIN1_PASSWORD` | 老师账号、姓名、强初始密码 |
| `ADMIN2_USERNAME` / `ADMIN2_NAME` / `ADMIN2_PASSWORD` | 负责人账号、姓名、强初始密码 |
| `SITE_ADDRESS` | 域名或 `:80`（仅临时IP测试） |
| `DJANGO_ALLOWED_HOSTS` | 你将访问的域名 / IP，逗号分隔 |

**推荐正式域名 + HTTPS**：先配置域名 A 记录指向云服务器，再在 `.env` 设置：

```dotenv
SITE_ADDRESS=invoice.your-lab.cn
DJANGO_ALLOWED_HOSTS=invoice.your-lab.cn
DJANGO_HTTPS=1
DJANGO_CSRF_TRUSTED_ORIGINS=https://invoice.your-lab.cn
```

Caddy 将自动申请并续期 HTTPS 证书。没有域名时，可先使用 `.env.example` 的 `:80` 与服务器公网IP测试；**HTTP 未加密，不建议实际上传含隐私的发票，正式使用务必上 HTTPS**。

运行：

```bash
docker compose up -d --build
docker compose ps
docker compose logs -f --tail=100 web
```

首次启动自动执行数据库迁移、静态资源收集并创建 2 个管理员。打开 `https://你的域名/`（或临时的 `http://服务器IP/`）。两位管理员初次登录后会被要求修改密码。

初始化成功后，建议将 `.env` 中 `ADMIN1_PASSWORD` 和 `ADMIN2_PASSWORD` 清空，随后 `docker compose up -d` 更新容器。**初始化脚本发现已有两个管理员时不会重置其现有密码。** 管理员应使用密码管理器，不要通过公开群聊发送初始密码。

> 如果启动失败：先运行 `docker compose ps` 和 `docker compose logs --tail=100 web db caddy`。检查 `.env` 未保留占位符，DNS 是否已解析，80/443 是否放行，数据库是否健康。

## 3. 日常使用

### 管理员

1. 登录，进入“本周发票”：显示成员人数、已上传人数及“张三发票”等目录。
2. 点击某成员 → 查看文件或进入“顺丰快递”等文件夹 → 单文件下载、或“下载全部”。
3. 点击“下载本周全部发票” → 获得按成员姓名分文件夹的 ZIP。
4. 确认资料齐全后点击“归档本周”，此后成员无法继续修改该周。需补充时可“重新开放”。
5. “成员管理”中创建账号或为遗忘密码的成员重设密码（管理员无法查看原密码）。

### 成员

1. 用管理员分配的账号登录，首次登录修改初始密码。
2. 默认是本周个人文件；可以选择多份发票，也可以选择整个文件夹（包含运单等附件）。
3. 可自行新建文件夹、修改名称、移动文件。重复文件名会自动追加编号避免覆盖。
4. “历史周次”查看过去提交的文件；历史周次如果仍开放，也可补充上传。
5. “操作记录”查看上传和管理文件的时间；回收站可恢复误删文件（归档状态只读）。

**时间分组**：周一 00:00 到周日 23:59:59，中国标准时间 `Asia/Shanghai`。界面标签按郑州大学校历：2026-09-07开始秋季第1周，2027-02-22开始春季第1周。假期有独立周次；校历未配置的日期会标示“校历待更新”，不能误认作教学周。下个学年需更新 `invoices/academic_calendar.py`。数据库仍按周一日期存储，历史文件不会迁移或丢失。

## 4. 支持的文件格式 / 限制

PDF、OFD、JPG、JPEG、PNG、WEBP、XLS、XLSX、DOC、DOCX、ZIP。

- 单文件不超过 **30 MB**；一次不超过 **30 个文件 / 150 MB**。
- 支持嵌套最多10层子文件夹。支持多文件上传、浏览器文件夹上传。
- PDF及常见图片可尝试浏览器内预览，其余类型会转为下载；OFD依赖本地阅读器。
- ZIP 等上传文件只存储，不在服务器端解压，减少不可信文件风险。
- 服务器磁盘占用会随文件增加；请监控磁盘容量。

## 5. 持久化与备份（非常重要）

Docker Compose 使用下列命名卷（`docker compose down` **不要加 `-v`**）：

| 卷 | 内容 |
| --- | --- |
| `db_data` | PostgreSQL 数据库（用户、目录树、历史记录） |
| `private_files` | 发票原文件（不经公网静态目录暴露） |
| `static_files` | 前端CSS/JS |
| `caddy_data` | HTTPS 证书与配置 |

每天至少备份数据库和上传文件，并将备份**加密复制到另一台机器或受控的对象存储**。项目提供手动备份脚本：

```bash
bash scripts/backup.sh
```

备份输出到 `./backups/YYYYmmdd_HHMMSS/`，包含数据库 SQL（gzip）和上传文件（tar.gz）。测试恢复时应先在隔离环境还原 DB 和上传卷，检查任意周的文件均可下载。

升级前先备份。更新代码后执行 `docker compose up -d --build` 即可自动迁移数据库，注意预留可用磁盘空间。**勿使用 `docker compose down -v`**，否则卷中数据可能被永久删除。

## 6. 安全说明 / 上线前检查

- 数据文件只存放私有 Docker 卷；下载和预览均通过鉴权 Django 路由；成员间严格权限隔离。
- 密码由 Django 安全哈希保存，新密码仅要求至少包含一个英文字母和一个数字，特殊符号可选，不限制长度或大小写（出于安全建议使用8位以上，但不强制）；首次登录强制换密；管理员重置不会展示旧密码。旧密码在登录时继续有效。
- 关键写操作带 CSRF 校验；上传按扩展名、常见文件签名、大小和路径验证；使用服务器生成的随机存储文件名。
- 失败登录限速：同账号 + 来源IP，15分钟内8次失败后限制尝试。
- 含个人信息的发票仅允许经管理员授权的成员使用，遵守实验室数据和财务管理规定。
- **上线必须使用 HTTPS**、强密码及定期离线备份；建议仅实验室人员访问（可在云防火墙进一步限制来源）。
- 管理员为同权限，均可关闭/重新开放任何周；管理员账号仅首次初始化，不在 UI 创建第三位管理员。
- 未引入反病毒扫描或专业恶意文件检测；下载 Office/ZIP 等文件时客户端应开启系统防护。

## 7. 开发与自检

在本机具有 Python 3.12、pip 且网络可访问时：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
DB_ENGINE=sqlite DJANGO_DEBUG=1 python manage.py migrate
DB_ENGINE=sqlite DJANGO_DEBUG=1 python manage.py test invoices
DB_ENGINE=sqlite DJANGO_DEBUG=1 python manage.py check
```

生产环境数据库为 PostgreSQL，开发自检使用 SQLite。另可运行：

```bash
docker compose exec web python manage.py check --deploy
```

**交付验证备注**：源代码、模板、Docker 配置和集成测试已一并提供。但交付机器没有可联网安装的 Django 环境，也没有 Docker 引擎，因此**无法在本次制作环境中实际运行 Django 测试、容器构建及真实 HTTPS 部署**。项目须在你的云服务器执行上述命令完成最终部署验证，不能把静态语法检查当成运行通过。

## 8. 项目结构

```text
lab_invoice_system/
├── compose.yaml             Docker Compose 应用/数据库/网关
├── Dockerfile                Python 应用镜像
├── Caddyfile                 反向代理、HTTPS、上传体积限制
├── .env.example              部署环境变量模板
├── manage.py / config/       Django 配置
├── invoices/
│   ├── models.py             用户、周次、文件夹、文件、流水
│   ├── views.py / urls.py     业务逻辑、权限、下载/上传路由
│   ├── services.py / forms.py 验证和表单
│   ├── migrations/           数据库初始迁移
│   ├── templates/            PC/手机适配网页
│   ├── static/               CSS和JavaScript
│   ├── management/commands/  两管理员初始化
│   └── tests.py              业务测试
├── scripts/                  自动启动和备份脚本
└── docs/                     需求规格说明书
```

## 9. 后续可扩展

第二阶段可按实际需要加入批量拖拽上传、可配置提醒、发票OCR识别、金额/课题经费台账、上传截止日期、Excel导出、发票重复性检测。但当前版本不引入会增加成员操作成本的审批流程。


## V1.1 校历 / 密码更新（2026-10-26）

- 统一规则：首次改密、个人改密、管理员创建/重置成员密码、初始化管理员账号都只校验英文字母和数字至少各1个；无需特殊符号、无额外长度要求（使用特殊符号也允许）。建议用户自愿设置更长的密码。
- 日期基准：郑州大学 2026—2027 学年，秋季第1周是 2026-09-07 至 09-13，第8周是 10-26 至 11-01；春季第1周是 2027-02-22 至 02-28；学年后续请维护 `invoices/academic_calendar.py`。
- 不改数据库 `start_date`，已上传文件、历史记录及归档标记保留；已存在的管理员/成员密码原样有效。
- 本版将模型索引名称与原有 0001_initial 迁移文件保持一致，以消除“model changes are not yet reflected in a migration”提示。
- 从V1.0升级：不要覆盖服务器的 `.env`，不要执行 `docker compose down -v`。可在原 `~/fapiao` 目录解压本版覆盖源文件，再运行 `docker compose up -d --build`。
