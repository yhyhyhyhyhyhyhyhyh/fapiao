"""Unified password policy: at least one ASCII letter and one digit.

Existing passwords remain valid for login; this policy is applied when passwords
are created, changed, or reset. There is no minimum length or mandatory symbol/case requirement.
"""
import re
from django.core.exceptions import ValidationError
from django.utils.deconstruct import deconstructible


@deconstructible
class LettersAndNumbersValidator:
    def validate(self, password, user=None):
        if not (re.search(r'[A-Za-z]', password or '')
                and re.search(r'[0-9]', password or '')):
            raise ValidationError(
                '密码至少需要包含一个英文字母和一个数字。',
                code='letters_and_numbers_required',
            )

    def get_help_text(self):
        return '密码至少包含一个英文字母和一个数字；没有长度或大小写限制，特殊符号可选。'
