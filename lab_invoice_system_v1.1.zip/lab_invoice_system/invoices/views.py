import io
import json
import tempfile
import zipfile
from datetime import timedelta
from pathlib import PurePosixPath
from functools import wraps
from urllib.parse import urlencode
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q
from django.http import FileResponse, Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST, require_http_methods
from .forms import AdminResetPasswordForm, MemberCreateForm, MemberEditForm
from .models import Activity, Folder, InvoiceFile, LoginAttempt, User, Week
from .services import (audit, create_folder_path, current_week, filename_type, folder_by_id, folder_depth,
                       is_descendant, nested_folders, safe_relative_path, subtree_height, unique_name,
                       validate_name, validate_upload, visible_folder)


def admin_required(fn):
    @login_required
    @wraps(fn)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_lab_admin:
            raise PermissionDenied('只有管理员可访问此页面。')
        return fn(request, *args, **kwargs)
    return wrapper


def get_week(week_id):
    return get_object_or_404(Week, pk=week_id)


def get_owner(request, owner_id):
    owner = get_object_or_404(User, pk=owner_id, role=User.Role.MEMBER)
    if not request.user.is_lab_admin and request.user.pk != owner.pk:
        raise PermissionDenied('无权访问其他成员的发票。')
    return owner


def writable_week(request, week_id):
    week = get_object_or_404(Week.objects.select_for_update(), pk=week_id)
    if request.user.is_lab_admin:
        raise PermissionDenied('管理员只整理及归档，不直接修改成员原始文件。')
    if week.is_archived:
        raise PermissionDenied('本周已归档，无法更改文件；请联系管理员重新开放。')
    return week


def back_to_browse(week, user, folder=None):
    base = reverse('browse', args=[week.pk, user.pk])
    return f'{base}?{urlencode({"folder": folder.pk})}' if folder else base


def flash_validation(request, exc):
    if hasattr(exc, 'messages'):
        messages.error(request, '；'.join(exc.messages))
    else:
        messages.error(request, str(exc))


def item_for_change(week, owner, kind, pk):
    model = Folder if kind == 'folder' else InvoiceFile if kind == 'file' else None
    if model is None:
        raise ValidationError('未知的文件类型。')
    item = get_object_or_404(model, pk=pk, week=week, owner=owner, trashed_at__isnull=True)
    parent = item.parent if kind == 'folder' else item.folder
    if parent and not visible_folder(parent):
        raise ValidationError('文件位于已删除的文件夹中。')
    return item


def file_access(request, file_id):
    f = get_object_or_404(InvoiceFile.objects.select_related('owner', 'week', 'folder'), pk=file_id)
    if not request.user.is_lab_admin and request.user.pk != f.owner_id:
        raise PermissionDenied
    if f.trashed_at or (f.folder and not visible_folder(f.folder)):
        raise Http404
    return f


@require_http_methods(['GET', 'POST'])
def signin(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        ip = request.META.get('REMOTE_ADDR', 'unknown')[:50]
        cutoff = timezone.now() - timedelta(minutes=15)
        LoginAttempt.objects.filter(created_at__lt=timezone.now() - timedelta(days=1)).delete()
        if LoginAttempt.objects.filter(username__iexact=username, client_ip=ip,
                                       created_at__gte=cutoff).count() >= 8:
            messages.error(request, '尝试次数过多，请15分钟后再试。')
        else:
            user = authenticate(request, username=username, password=password)
            if user and user.is_active:
                LoginAttempt.objects.filter(username__iexact=username, client_ip=ip).delete()
                login(request, user)
                return redirect('index')
            LoginAttempt.objects.create(username=username[:150], client_ip=ip)
            messages.error(request, '账号或密码不正确。')
    return render(request, 'invoices/login.html')


@login_required
@require_POST
def signout(request):
    logout(request)
    return redirect('login')


@login_required
@require_http_methods(['GET', 'POST'])
def change_password(request):
    form = PasswordChangeForm(request.user, request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save(commit=False)
        user.must_change_password = False
        user.save(update_fields=['password', 'must_change_password'])
        update_session_auth_hash(request, user)
        messages.success(request, '密码更新成功。')
        return redirect('index')
    return render(request, 'invoices/form.html', {'form': form,
        'title': '设置新密码' if request.user.must_change_password else '修改密码',
        'subtitle': '初次登录必须修改初始密码。新密码至少包含一个英文字母和一个数字即可，无额外复杂度要求。',
        'submit_label': '保存新密码', 'require_change': request.user.must_change_password})


@login_required
@require_GET
def index(request):
    week = current_week()
    return redirect('week_detail', week_id=week.pk)


@login_required
@require_GET
def week_list(request):
    current = current_week()
    # Allow late submission to recent weeks even when nobody visited that week.
    for offset in range(12):
        Week.objects.get_or_create(start_date=current.start_date - timedelta(weeks=offset))
    weeks = Week.objects.order_by('-start_date')
    return render(request, 'invoices/weeks.html', {'weeks': weeks, 'active_tab': 'weeks'})


@login_required
@require_GET
def week_detail(request, week_id):
    week = get_week(week_id)
    if not request.user.is_lab_admin:
        return redirect('browse', week_id=week.pk, owner_id=request.user.pk)
    members = list(User.objects.filter(role=User.Role.MEMBER).order_by('display_name', 'username'))
    # Count only files actually visible outside the recycle bin.
    counts = {m.pk: 0 for m in members}
    root_count = {m.pk: 0 for m in members}
    for f in InvoiceFile.objects.filter(week=week, trashed_at__isnull=True).select_related('folder__parent'):
        if f.owner_id in counts and (not f.folder or visible_folder(f.folder)):
            counts[f.owner_id] += 1
    for folder in Folder.objects.filter(week=week, parent__isnull=True, trashed_at__isnull=True):
        if folder.owner_id in root_count:
            root_count[folder.owner_id] += 1
    for m in members:
        m.file_count = counts[m.pk]
        m.folder_count = root_count[m.pk]
        m.submitted = m.file_count > 0
    submitted = sum(1 for m in members if m.submitted)
    return render(request, 'invoices/admin_week.html', {
        'week': week, 'members': members, 'submitted': submitted,
        'total': len(members), 'unsubmitted': len(members) - submitted, 'active_tab': 'dashboard',
    })


@login_required
@require_GET
def browse(request, week_id, owner_id):
    week, owner = get_week(week_id), get_owner(request, owner_id)
    try:
        folder = folder_by_id(week, owner, request.GET.get('folder'))
    except (Folder.DoesNotExist, ValidationError, ValueError, TypeError):
        raise Http404('文件夹不存在。')
    folders = Folder.objects.filter(week=week, owner=owner, parent=folder, trashed_at__isnull=True)
    files = InvoiceFile.objects.filter(week=week, owner=owner, folder=folder, trashed_at__isnull=True)
    crumbs = []
    node = folder
    while node:
        crumbs.insert(0, node)
        node = node.parent
    return render(request, 'invoices/browser.html', {
        'week': week, 'owner': owner, 'folder': folder, 'folders': folders, 'files': files,
        'crumbs': crumbs, 'destinations': nested_folders(week, owner),
        'editable': not request.user.is_lab_admin and not week.is_archived,
        'active_tab': 'dashboard',
    })


@admin_required
@require_POST
def archive(request, week_id):
    with transaction.atomic():
        week = Week.objects.select_for_update().get(pk=week_id)
        week.is_archived = not week.is_archived
        week.archived_at = timezone.now() if week.is_archived else None
        week.archived_by = request.user if week.is_archived else None
        week.save(update_fields=['is_archived', 'archived_at', 'archived_by'])
        audit(request.user, None, week, 'archive' if week.is_archived else 'reopen',
              f'{week.label}：' + ('已归档' if week.is_archived else '重新开放'))
    messages.success(request, '周次已归档。' if week.is_archived else '已重新开放上传。')
    return redirect('week_detail', week_id=week.pk)


@login_required
@require_POST
@transaction.atomic
def create_folder(request, week_id):
    week = writable_week(request, week_id)
    try:
        parent = folder_by_id(week, request.user, request.POST.get('parent_id'))
        name = validate_name(request.POST.get('name'))
        if folder_depth(parent) >= 10:
            raise ValidationError('文件夹层级最多10层。')
        with transaction.atomic():
            name = unique_name(Folder, name, week, request.user, parent)
            Folder.objects.create(week=week, owner=request.user, parent=parent, name=name)
            audit(request.user, request.user, week, 'mkdir', f'新建文件夹：{name}')
        messages.success(request, '文件夹已创建。')
    except (ValidationError, Folder.DoesNotExist, ValueError, TypeError) as exc:
        flash_validation(request, exc)
    return redirect(back_to_browse(week, request.user, parent if 'parent' in locals() else None))


@login_required
@require_POST
@transaction.atomic
def upload(request, week_id):
    week = writable_week(request, week_id)
    try:
        parent = folder_by_id(week, request.user, request.POST.get('parent_id'))
        files = request.FILES.getlist('files') + request.FILES.getlist('folder_files')
        paths = request.POST.getlist('paths')
        if not files:
            raise ValidationError('请先选择要上传的文件。')
        if len(files) > settings.MAX_BATCH_FILES or sum(f.size for f in files) > settings.MAX_BATCH_SIZE:
            raise ValidationError('一次最多上传30个文件，总大小不超过150 MB。')
        if paths and len(paths) != len(files):
            raise ValidationError('文件夹结构信息有误，请重新选择文件。')
        parsed = []
        for i, incoming in enumerate(files):
            name = validate_upload(incoming)
            segments = safe_relative_path(paths[i] if paths else name)
            if segments[-1] != name:
                raise ValidationError('上传的文件名与路径不匹配。')
            parsed.append((incoming, name, segments[:-1]))
        with transaction.atomic():
            for incoming, name, subdirs in parsed:
                destination = create_folder_path(week, request.user, parent, subdirs)
                unique = unique_name(InvoiceFile, name, week, request.user, destination)
                InvoiceFile.objects.create(week=week, owner=request.user,
                    folder=destination, name=unique, blob=incoming,
                    size=incoming.size, content_type=incoming.content_type or '')
                audit(request.user, request.user, week, 'upload', f'上传：{unique}')
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'ok': True, 'message': f'成功上传 {len(files)} 个文件。'})
        messages.success(request, f'成功上传 {len(files)} 个文件。')
    except (ValidationError, Folder.DoesNotExist, ValueError, TypeError) as exc:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'ok': False, 'message': '；'.join(exc.messages) if hasattr(exc, 'messages') else str(exc)}, status=400)
        flash_validation(request, exc)
    return redirect(back_to_browse(week, request.user, parent if 'parent' in locals() else None))


@login_required
@require_POST
@transaction.atomic
def rename(request, week_id):
    week = writable_week(request, week_id)
    try:
        item = item_for_change(week, request.user, request.POST.get('kind'), request.POST.get('id'))
        new_name = validate_name(request.POST.get('name'))
        if isinstance(item, InvoiceFile):
            old_suffix = PurePosixPath(item.name).suffix.lower()
            if PurePosixPath(new_name).suffix.lower() != old_suffix:
                raise ValidationError('为保证发票格式正确，重命名时不能修改文件扩展名。')
        parent = item.parent if isinstance(item, Folder) else item.folder
        new_name = unique_name(Folder if isinstance(item, Folder) else InvoiceFile,
                               new_name, week, request.user, parent, item.pk)
        old = item.name
        item.name = new_name
        item.save(update_fields=['name', 'updated_at'])
        audit(request.user, request.user, week, 'rename', f'重命名：{old} → {new_name}')
        messages.success(request, '重命名成功。')
    except ValidationError as exc:
        flash_validation(request, exc)
    try:
        parent_for_return = folder_by_id(week, request.user, request.POST.get('back_folder'))
    except (ValidationError, Folder.DoesNotExist, ValueError, TypeError):
        parent_for_return = None
    return redirect(back_to_browse(week, request.user, parent_for_return))


@login_required
@require_POST
@transaction.atomic
def move_item(request, week_id):
    week = writable_week(request, week_id)
    try:
        item = item_for_change(week, request.user, request.POST.get('kind'), request.POST.get('id'))
        dest = folder_by_id(week, request.user, request.POST.get('destination'))
        if isinstance(item, Folder) and dest and is_descendant(dest, item):
            raise ValidationError('不能将文件夹移动到自己或自己的子文件夹中。')
        if isinstance(item, Folder) and folder_depth(dest) + subtree_height(item) > 10:
            raise ValidationError('目标目录层级不能超过10层。')
        item.name = unique_name(Folder if isinstance(item, Folder) else InvoiceFile,
                                item.name, week, request.user, dest, item.pk)
        if isinstance(item, Folder):
            item.parent = dest
            item.save(update_fields=['name', 'parent', 'updated_at'])
        else:
            item.folder = dest
            item.save(update_fields=['name', 'folder', 'updated_at'])
        audit(request.user, request.user, week, 'move', f'移动：{item.name}')
        messages.success(request, '移动成功。')
    except (ValidationError, Folder.DoesNotExist) as exc:
        flash_validation(request, exc)
    return redirect(back_to_browse(week, request.user))


@login_required
@require_POST
@transaction.atomic
def delete_item(request, week_id):
    week = writable_week(request, week_id)
    try:
        item = item_for_change(week, request.user, request.POST.get('kind'), request.POST.get('id'))
        item.trashed_at = timezone.now()
        item.save(update_fields=['trashed_at', 'updated_at'])
        audit(request.user, request.user, week, 'trash', f'移至回收站：{item.name}')
        messages.success(request, '已移至回收站。')
    except ValidationError as exc:
        flash_validation(request, exc)
    return redirect(back_to_browse(week, request.user))


@login_required
@require_GET
def trash_list(request, week_id):
    week = get_week(week_id)
    if request.user.is_lab_admin:
        raise PermissionDenied('成员回收站属于个人空间。')
    return render(request, 'invoices/trash.html', {
        'week': week,
        'folders': Folder.objects.filter(week=week, owner=request.user, trashed_at__isnull=False),
        'files': InvoiceFile.objects.filter(week=week, owner=request.user, trashed_at__isnull=False),
        'active_tab': 'dashboard',
    })


@login_required
@require_POST
@transaction.atomic
def restore_item(request, week_id):
    week = writable_week(request, week_id)
    kind = request.POST.get('kind')
    model = Folder if kind == 'folder' else InvoiceFile if kind == 'file' else None
    if model is None:
        raise Http404
    item = get_object_or_404(model, pk=request.POST.get('id'), week=week,
                             owner=request.user, trashed_at__isnull=False)
    parent = item.parent if kind == 'folder' else item.folder
    if parent and not visible_folder(parent):
        messages.error(request, '请先恢复其上级文件夹。')
        return redirect('trash_list', week_id=week.pk)
    item.name = unique_name(model, item.name, week, request.user, parent, item.pk)
    item.trashed_at = None
    item.save(update_fields=['name', 'trashed_at', 'updated_at'])
    audit(request.user, request.user, week, 'restore', f'恢复：{item.name}')
    messages.success(request, '恢复成功。')
    return redirect('trash_list', week_id=week.pk)


def file_response(f, inline=False):
    if not f.blob.storage.exists(f.blob.name):
        raise Http404('原始文件不存在，请联系管理员检查服务器备份。')
    content_type = filename_type(f) if inline else 'application/octet-stream'
    resp = FileResponse(f.blob.open('rb'), as_attachment=not inline,
                        filename=f.name, content_type=content_type)
    resp['Cache-Control'] = 'private, no-store'
    return resp


@login_required
@require_GET
def download_file(request, file_id):
    return file_response(file_access(request, file_id))


@login_required
@require_GET
def preview_file(request, file_id):
    f = file_access(request, file_id)
    if filename_type(f) == 'application/octet-stream':
        return file_response(f)
    return file_response(f, inline=True)


def normalized_zip_segment(name):
    # Zip paths are built solely from validated database names.
    return validate_name(name)


def zip_member(zf, week, owner, base):
    """Preserve nested subdirectories (including empty folders)."""
    folders = list(Folder.objects.filter(week=week, owner=owner, trashed_at__isnull=True))
    lookup = {f.pk: f for f in folders}
    memo = {}
    def relative(folder):
        if not folder:
            return ''
        if folder.pk in memo:
            return memo[folder.pk]
        if folder.trashed_at or (folder.parent_id and folder.parent_id not in lookup):
            memo[folder.pk] = None
            return None
        parent_path = relative(lookup.get(folder.parent_id)) if folder.parent_id else ''
        if parent_path is None:
            memo[folder.pk] = None
            return None
        result = parent_path + normalized_zip_segment(folder.name) + '/'
        memo[folder.pk] = result
        return result
    for folder in folders:
        rel = relative(folder)
        if rel is not None:
            zf.writestr(base + rel, b'')
    for f in InvoiceFile.objects.filter(week=week, owner=owner, trashed_at__isnull=True):
        rel = relative(lookup.get(f.folder_id)) if f.folder_id else ''
        if rel is None:
            continue
        arc_name = base + rel + normalized_zip_segment(f.name)
        if not f.blob.storage.exists(f.blob.name):
            continue
        with f.blob.open('rb') as source, zf.open(arc_name, 'w') as dest:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                dest.write(chunk)


def zip_response(week, owners, filename):
    tmp = tempfile.TemporaryFile(mode='w+b')
    with zipfile.ZipFile(tmp, 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        used = set()
        for owner in owners:
            base_name = normalized_zip_segment(owner.shown_name) + '发票'
            name = base_name
            counter = 0
            while name in used:
                counter += 1
                name = f'{base_name}_{owner.username}' + (f'_{counter}' if counter > 1 else '')
            used.add(name)
            zf.writestr(name + '/', b'')
            zip_member(zf, week, owner, name + '/')
    tmp.seek(0)
    resp = FileResponse(tmp, as_attachment=True, filename=filename, content_type='application/zip')
    resp['Cache-Control'] = 'private, no-store'
    return resp


@login_required
@require_GET
def download_member_zip(request, week_id, owner_id):
    week = get_week(week_id)
    owner = get_owner(request, owner_id)
    return zip_response(week, [owner], f'{week.label}_{owner.shown_name}发票.zip')


@admin_required
@require_GET
def download_week_zip(request, week_id):
    week = get_week(week_id)
    owners = User.objects.filter(role=User.Role.MEMBER).order_by('display_name', 'username')
    return zip_response(week, owners, f'{week.label}_全部发票.zip')


@login_required
@require_GET
def history(request):
    activities = Activity.objects.select_related('actor', 'owner', 'week')
    if not request.user.is_lab_admin:
        activities = activities.filter(owner=request.user)
    week_id = request.GET.get('week')
    if week_id:
        activities = activities.filter(week_id=week_id)
    page = Paginator(activities, 30).get_page(request.GET.get('page'))
    return render(request, 'invoices/history.html', {
        'page': page, 'weeks': Week.objects.all(), 'chosen_week': week_id,
        'active_tab': 'history',
    })


@admin_required
@require_GET
def member_list(request):
    members = User.objects.filter(role=User.Role.MEMBER).order_by('display_name', 'username')
    return render(request, 'invoices/members.html', {'members': members, 'active_tab': 'members'})


@admin_required
@require_http_methods(['GET', 'POST'])
def member_add(request):
    form = MemberCreateForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        with transaction.atomic():
            m = form.save()
            audit(request.user, m, None, 'member_add', f'创建成员账号：{m.shown_name} ({m.username})')
        messages.success(request, f'成员 {m.shown_name} 已创建，请将初始密码安全地发送给本人。')
        return redirect('member_list')
    return render(request, 'invoices/form.html', {'form': form, 'title': '添加课题组成员',
        'subtitle': '成员登录后必须修改初始密码。', 'submit_label': '创建账号', 'active_tab': 'members'})


def target_member(member_id):
    return get_object_or_404(User, pk=member_id, role=User.Role.MEMBER)


@admin_required
@require_http_methods(['GET', 'POST'])
def member_edit(request, member_id):
    member = target_member(member_id)
    form = MemberEditForm(request.POST or None, instance=member)
    if request.method == 'POST' and form.is_valid():
        form.save()
        audit(request.user, member, None, 'member_edit', f'修改成员资料：{member.shown_name}')
        messages.success(request, '成员资料已更新。')
        return redirect('member_list')
    return render(request, 'invoices/form.html', {'form': form, 'title': f'编辑成员：{member.shown_name}',
        'subtitle': f'登录账号：{member.username}（账号固定，姓名可以更改）',
        'submit_label': '保存修改', 'active_tab': 'members'})


@admin_required
@require_http_methods(['GET', 'POST'])
def member_password(request, member_id):
    member = target_member(member_id)
    form = AdminResetPasswordForm(request.POST or None, target_user=member)
    if request.method == 'POST' and form.is_valid():
        member.set_password(form.cleaned_data['password1'])
        member.must_change_password = True
        member.save(update_fields=['password', 'must_change_password'])
        audit(request.user, member, None, 'password_reset', f'管理员重置 {member.shown_name} 的密码')
        messages.success(request, '初始密码已重置，成员下次登录需修改。')
        return redirect('member_list')
    return render(request, 'invoices/form.html', {'form': form,
        'title': f'重置密码：{member.shown_name}',
        'subtitle': '不会展示成员现有密码。重置后旧密码立即失效。',
        'submit_label': '重置密码', 'active_tab': 'members'})


@admin_required
@require_POST
def member_toggle(request, member_id):
    member = target_member(member_id)
    member.is_active = not member.is_active
    member.save(update_fields=['is_active'])
    audit(request.user, member, None, 'member_status',
          f'{member.shown_name}：' + ('启用账号' if member.is_active else '停用账号'))
    messages.success(request, '成员账号状态已更新。原有发票及历史记录仍保留。')
    return redirect('member_list')
