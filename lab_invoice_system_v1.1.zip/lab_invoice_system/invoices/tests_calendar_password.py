"""V1.1 tests for ZZU school-week numbering and uniform password rules."""
from datetime import date
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase
from .academic_calendar import academic_week_label
from .models import Week


class AcademicCalendarTests(SimpleTestCase):
    def test_fall_first_week(self):
        self.assertEqual(Week(start_date=date(2026, 9, 7)).label,
                         '2026—2027学年秋季学期第1周')

    def test_fall_eighth_week(self):
        self.assertEqual(Week(start_date=date(2026, 10, 26)).label,
                         '2026—2027学年秋季学期第8周')

    def test_fall_last_week_and_winter(self):
        self.assertEqual(academic_week_label(date(2027, 1, 11)),
                         '2026—2027学年秋季学期第19周')
        self.assertEqual(academic_week_label(date(2027, 1, 18)),
                         '2026—2027学年寒假第1周')

    def test_spring_week_and_summer(self):
        self.assertEqual(academic_week_label(date(2027, 2, 22)),
                         '2026—2027学年春季学期第1周')
        self.assertEqual(academic_week_label(date(2027, 7, 5)),
                         '2026—2027学年小学期第1周')
        self.assertEqual(academic_week_label(date(2027, 7, 26)),
                         '2026—2027学年暑假第1周')

    def test_unspecified_future_calendar_is_not_fake(self):
        self.assertIn('校历待更新', academic_week_label(date(2027, 9, 6)))


class PasswordPolicyTests(SimpleTestCase):
    def test_letters_and_digits_and_optional_symbols(self):
        for value in ('a1', 'abc123', 'ABC123', 'Ab12', 'A1!', 'ab 1'):
            with self.subTest(value=value):
                password_validation.validate_password(value)

    def test_reject_missing_letter_or_digit(self):
        for value in ('', 'a', '1234', 'ABCD', '甲1'):
            with self.subTest(value=value), self.assertRaises(ValidationError):
                password_validation.validate_password(value)


class PasswordFormTests(TestCase):
    def test_member_creation_accepts_short_alphanumeric(self):
        from .forms import MemberCreateForm
        form = MemberCreateForm(data={
            'username': 'newstudent', 'display_name': '新成员',
            'password1': 'abc123', 'password2': 'abc123',
        })
        self.assertTrue(form.is_valid(), form.errors)

    def test_member_creation_rejects_numeric_only(self):
        from .forms import MemberCreateForm
        form = MemberCreateForm(data={
            'username': 'newstudent', 'display_name': '新成员',
            'password1': '123456', 'password2': '123456',
        })
        self.assertFalse(form.is_valid())
        self.assertIn('password1', form.errors)
