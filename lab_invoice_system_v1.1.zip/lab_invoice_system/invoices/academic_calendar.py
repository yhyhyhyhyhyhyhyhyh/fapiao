"""郑州大学 2026—2027 学年校历（按用户提供的官方校历图核对）。

以自然周周一作为文件归档的唯一标识，不改动已有 Week.start_date；
周次标签独立展示为校历周次，避免 ISO 年周与学期周混淆。
新增学年时请在 PERIODS 追加学校正式公布的校历日期。
"""
from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class AcademicPeriod:
    start: date
    end: date
    year: str
    title: str


PERIODS = (
    AcademicPeriod(date(2026, 9, 7), date(2027, 1, 17), '2026—2027', '秋季学期'),
    AcademicPeriod(date(2027, 1, 18), date(2027, 2, 21), '2026—2027', '寒假'),
    AcademicPeriod(date(2027, 2, 22), date(2027, 7, 4), '2026—2027', '春季学期'),
    AcademicPeriod(date(2027, 7, 5), date(2027, 7, 25), '2026—2027', '小学期'),
    AcademicPeriod(date(2027, 7, 26), date(2027, 9, 5), '2026—2027', '暑假'),
)


def academic_week_label(monday: date) -> str:
    """Academic semester label for an existing Monday-anchored Week row."""
    for period in PERIODS:
        if period.start <= monday <= period.end:
            nth = ((monday - period.start).days // 7) + 1
            return f'{period.year}学年{period.title}第{nth}周'
    # Outside the configured official calendar, never pretend to know the term.
    iso_year, iso_week, _ = monday.isocalendar()
    return f'{iso_year}年第{iso_week:02d}周（校历待更新）'
