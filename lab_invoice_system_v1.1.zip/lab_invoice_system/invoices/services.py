"""Shared validations and access helpers. Never trust paths supplied by clients."""
import mimetypes
import unicodedata
from datetime import timedelta
from pathlib import PurePosixPath
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db.models import Q
from django.utils import timezone
from .models import Activity, Folder, InvoiceFile, Week


def current_monday():
    local_date = timezone.localdate()
    return local_date - timedelta(days=local_date.weekday())


def current_week():
    return Week.objects.get_or_create(start_date=current_monday())[0]


def audit(actor, owner, week, action, description):
    Activity.objects.create(actor=actor, owner=owner, week=week, action=action,
                            description=description[:300])


def validate_name(name):
    name = unicodedata.normalize('NFC', str(name or '')).strip()
    if not name or len(name) > 160 or name in {'.', '..'}:
        raise ValidationError('名称长度必须在1—160个字符之间。')
    if '/' in name or '\\' in name or any(unicodedata.category(ch).startswith('C') for ch in name):
        raise ValidationError('名称不能包含斜杠或控制字符。')
    return name


def safe_relative_path(path):
    path = (path or '').replace('\\', '/')
    components = path.split('/')
    if len(components) > 11 or any(part in {'', '.', '..'} for part in components):
        raise ValidationError('文件夹层级不可超过10层，且路径不能包含特殊目录。')
    return [validate_name(part) for part in components]


def validate_upload(file):
    name = validate_name(file.name)
    suffix = PurePosixPath(name).suffix.lower()
    if suffix not in settings.ALLOWED_FILE_EXTENSIONS:
        raise ValidationError(f'不支持此文件类型：{suffix or "无扩展名"}。')
    if file.size == 0 or file.size > settings.MAX_FILE_SIZE:
        raise ValidationError(f'文件 {name} 不能为空或大于30 MB。')
    # Common image/PDF signatures prevent trivial masquerading.
    pos = file.tell()
    signature = file.read(12)
    file.seek(pos)
    checks = {'.pdf': signature.startswith(b'%PDF-'),
              '.png': signature.startswith(b'\x89PNG\r\n\x1a\n'),
              '.jpg': signature.startswith(b'\xff\xd8'),
              '.jpeg': signature.startswith(b'\xff\xd8'),
              '.webp': signature.startswith(b'RIFF') and signature[8:12] == b'WEBP'}
    if suffix in checks and not checks[suffix]:
        raise ValidationError(f'{name} 文件内容与扩展名不匹配。')
    return name


def visible_folder(folder):
    node = folder
    seen = set()
    while node:
        if node.pk in seen or node.trashed_at is not None:
            return False
        seen.add(node.pk)
        node = node.parent
    return True


def folder_by_id(week, owner, pk, require_visible=True):
    if not pk:
        return None
    folder = Folder.objects.select_related('parent').get(pk=pk, week=week, owner=owner)
    if require_visible and not visible_folder(folder):
        raise ValidationError('目标文件夹不存在或已删除。')
    return folder


def unique_name(model, name, week, owner, parent=None, exclude_id=None):
    name = validate_name(name)
    field = 'parent' if model is Folder else 'folder'
    query = {field: parent, 'week': week, 'owner': owner, 'trashed_at__isnull': True}
    used = model.objects.filter(**query)
    if exclude_id:
        used = used.exclude(pk=exclude_id)
    known = set(used.values_list('name', flat=True))
    if name not in known:
        return name
    p = PurePosixPath(name)
    stem, suffix = (p.stem, p.suffix) if model is InvoiceFile else (name, '')
    for n in range(1, 10000):
        candidate = f'{stem[:150-len(suffix)-len(str(n))]} ({n}){suffix}'
        if candidate not in known:
            return candidate
    raise ValidationError('文件名重复次数过多。')


def nested_folders(week, owner):
    folders = list(Folder.objects.filter(week=week, owner=owner).select_related('parent'))
    active = {f.pk: f for f in folders if f.trashed_at is None}
    result = []
    def walk(parent_id, level, chain):
        if level > 10:
            return
        for f in folders:
            if f.pk in active and f.parent_id == parent_id and f.pk not in chain:
                result.append({'id': f.id, 'label': '　' * level + f.name, 'level': level})
                walk(f.pk, level + 1, chain | {f.pk})
    walk(None, 0, set())
    return result


def folder_depth(parent):
    depth = 0
    seen = set()
    while parent:
        if parent.pk in seen:
            raise ValidationError('文件夹结构异常。')
        seen.add(parent.pk)
        depth += 1
        parent = parent.parent
    return depth


def subtree_height(folder):
    """Maximum directory depth of a subtree, measured from its root."""
    descendants = Folder.objects.filter(week=folder.week, owner=folder.owner,
                                         trashed_at__isnull=True).values_list('pk', 'parent_id')
    children = {}
    for pk, parent_id in descendants:
        children.setdefault(parent_id, []).append(pk)
    def height(pk, seen):
        if pk in seen:
            raise ValidationError('文件夹结构异常。')
        return 1 + max((height(child, seen | {pk}) for child in children.get(pk, [])), default=0)
    return height(folder.pk, set())


def create_folder_path(week, owner, parent, segments):
    if folder_depth(parent) + len(segments) > 10:
        raise ValidationError('文件夹最多支持10层。')
    node = parent
    for segment in segments:
        name = validate_name(segment)
        existing = Folder.objects.filter(week=week, owner=owner, parent=node,
                                         name=name, trashed_at__isnull=True).first()
        if existing:
            node = existing
        else:
            node = Folder.objects.create(week=week, owner=owner, parent=node, name=name)
    return node


def filename_type(file):
    suffix = PurePosixPath(file.name).suffix.lower()
    return {
        '.pdf': 'application/pdf', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.png': 'image/png', '.webp': 'image/webp',
    }.get(suffix, 'application/octet-stream')


def is_descendant(candidate, ancestor):
    node = candidate
    while node:
        if node.pk == ancestor.pk:
            return True
        node = node.parent
    return False
