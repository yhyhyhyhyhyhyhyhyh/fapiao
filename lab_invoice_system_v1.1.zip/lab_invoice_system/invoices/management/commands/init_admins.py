"""Bootstrap EXACTLY two equal-privilege admin accounts; never reset existing passwords."""
import os
from django.contrib.auth import password_validation
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from invoices.models import User


class Command(BaseCommand):
    help = 'Create two admin accounts on first boot; leave existing passwords untouched.'

    @transaction.atomic
    def handle(self, *args, **options):
        admins = list(User.objects.filter(role=User.Role.ADMIN))
        if len(admins) == 2:
            self.stdout.write(self.style.SUCCESS('管理员账号已存在，跳过初始化（不会覆盖密码）。'))
            return
        if len(admins) > 2:
            raise CommandError('发现超过2个管理员，请人工审查数据库角色。')
        if not User.objects.filter(role=User.Role.ADMIN).exists() and os.getenv('ADMIN1_PASSWORD') == os.getenv('ADMIN2_PASSWORD'):
            raise CommandError('两位管理员的初始密码必须不同。')
        entries = []
        for i in (1, 2):
            username = os.getenv(f'ADMIN{i}_USERNAME', '').strip()
            display = os.getenv(f'ADMIN{i}_NAME', '').strip()
            password = os.getenv(f'ADMIN{i}_PASSWORD', '')
            if password.startswith('REPLACE_'):
                raise CommandError('管理员密码仍是 .env.example 占位符，请先替换。')
            if not username or not display or not password:
                raise CommandError('首次部署必须在 .env 填写 ADMIN1/2_USERNAME、NAME 和 PASSWORD。')
            if User.objects.filter(username__iexact=username).exclude(role=User.Role.ADMIN).exists():
                raise CommandError(f'账号 {username} 已被成员占用。')
            candidate = User(username=username, display_name=display)
            password_validation.validate_password(password, user=candidate)
            entries.append((username, display, password))
        if entries[0][0].lower() == entries[1][0].lower():
            raise CommandError('管理员用户名不能相同。')
        for username, display, password in entries:
            admin = User.objects.filter(username__iexact=username, role=User.Role.ADMIN).first()
            if admin:
                continue
            User.objects.create_user(username=username, display_name=display,
                password=password, role=User.Role.ADMIN, is_staff=True,
                is_superuser=False, must_change_password=True)
            self.stdout.write(f'创建管理员：{username}')
        if User.objects.filter(role=User.Role.ADMIN).count() != 2:
            raise CommandError('管理员初始化不完整，需检查配置。')
        self.stdout.write(self.style.SUCCESS('两位管理员创建成功，首次登录后需修改密码。'))
