import re
from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.forms import PasswordChangeForm
from django.core.exceptions import ValidationError
from .models import User
from .services import validate_name


class MemberCreateForm(forms.Form):
    username = forms.CharField(label='登录账号', max_length=30, help_text='3—30位英文字母、数字、点、下划线或短横线；字母开头')
    display_name = forms.CharField(label='成员姓名', max_length=60)
    password1 = forms.CharField(label='初始密码', widget=forms.PasswordInput,
        help_text='至少一个英文字母和一个数字即可，没有额外长度要求；特殊符号可选。')
    password2 = forms.CharField(label='确认密码', widget=forms.PasswordInput)

    def clean_display_name(self):
        return validate_name(self.cleaned_data['display_name'])

    def clean_username(self):
        name = self.cleaned_data['username'].strip()
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{2,29}', name):
            raise ValidationError('账号格式不正确。')
        if User.objects.filter(username__iexact=name).exists():
            raise ValidationError('该登录账号已存在。')
        return name

    def clean(self):
        data = super().clean()
        p1, p2 = data.get('password1'), data.get('password2')
        if p1 and p2 and p1 != p2:
            self.add_error('password2', '两次密码不一致。')
        if p1:
            candidate = User(username=data.get('username', ''), display_name=data.get('display_name', ''))
            try:
                password_validation.validate_password(p1, user=candidate)
            except ValidationError as exc:
                self.add_error('password1', exc)
        return data

    def save(self):
        d = self.cleaned_data
        return User.objects.create_user(username=d['username'], password=d['password1'],
                                        display_name=d['display_name'].strip(), role=User.Role.MEMBER,
                                        is_staff=False, is_superuser=False, must_change_password=True)


class MemberEditForm(forms.ModelForm):
    def clean_display_name(self):
        return validate_name(self.cleaned_data['display_name'])

    class Meta:
        model = User
        fields = ['display_name']
        labels = {'display_name': '成员姓名'}


class AdminResetPasswordForm(forms.Form):
    password1 = forms.CharField(label='新初始密码', widget=forms.PasswordInput,
        help_text='至少一个英文字母和一个数字即可，没有额外长度要求；特殊符号可选。')
    password2 = forms.CharField(label='确认新密码', widget=forms.PasswordInput)

    def __init__(self, *args, target_user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.target_user = target_user

    def clean(self):
        d = super().clean()
        p1, p2 = d.get('password1'), d.get('password2')
        if p1 and p2 and p1 != p2:
            self.add_error('password2', '两次密码不一致。')
        if p1:
            try:
                password_validation.validate_password(p1, user=self.target_user)
            except ValidationError as exc:
                self.add_error('password1', exc)
        return d
