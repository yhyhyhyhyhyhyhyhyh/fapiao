#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
backup_dir="backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup_dir"
chmod 700 backups "$backup_dir"
echo '[1/2] 导出PostgreSQL...'
docker compose exec -T db sh -c 'exec pg_dump --no-owner --no-acl -U "$POSTGRES_USER" "$POSTGRES_DB"' | gzip > "$backup_dir/database.sql.gz"
echo '[2/2] 导出私有发票文件...'
docker compose exec -T web tar -czf - -C /app/data private_uploads > "$backup_dir/private_uploads.tar.gz"
sha256sum "$backup_dir"/*.gz > "$backup_dir/SHA256SUMS.txt"
echo "备份完成：$backup_dir"
echo '务必将备份加密复制到另一台机器，并定期演练恢复。'
