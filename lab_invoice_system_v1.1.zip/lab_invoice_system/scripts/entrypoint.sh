#!/bin/sh
set -eu
python manage.py migrate --noinput
python manage.py collectstatic --noinput --clear
python manage.py init_admins
exec gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --threads 2 --timeout 180 --access-logfile - --error-logfile -
