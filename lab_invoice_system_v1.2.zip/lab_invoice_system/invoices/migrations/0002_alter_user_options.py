# User metadata option alignment; no schema/data operations.
from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [('invoices', '0001_initial')]

    operations = [
        migrations.AlterModelOptions(
            name='user',
            options={'verbose_name': 'user', 'verbose_name_plural': 'users'},
        ),
    ]
