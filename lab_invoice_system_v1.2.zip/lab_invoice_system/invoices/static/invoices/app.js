(() => {
  'use strict';
  const folderDialog = document.getElementById('folder-dialog');
  const itemDialog = document.getElementById('item-dialog');
  document.querySelectorAll('.close-modal').forEach(button => {
    button.addEventListener('click', () => button.closest('dialog')?.close());
  });
  document.querySelector('[data-create-folder]')?.addEventListener('click', () => {
    folderDialog?.showModal();
    folderDialog?.querySelector('input[name=name]')?.focus();
  });
  // Quick category chips in the nested-folder dialog.
  document.querySelectorAll('[data-folder-preset]').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.getElementById('new-folder-name');
      if (!input) return;
      input.value = button.dataset.folderPreset || '';
      input.focus();
    });
  });
  // Keep filtering purely presentational: ZIP authorization and selection
  // are computed on the server, regardless of what the user searches.
  const memberSearch = document.querySelector('[data-member-search]');
  memberSearch?.addEventListener('input', () => {
    const needle = memberSearch.value.trim().toLocaleLowerCase();
    document.querySelectorAll('[data-member-entry]').forEach(entry => {
      entry.hidden = !entry.dataset.memberLabel.toLocaleLowerCase().includes(needle);
      if (needle && !entry.hidden) entry.closest('details')?.setAttribute('open', '');
    });
  });
  const urls = document.getElementById('action-urls');
  document.querySelectorAll('[data-action]').forEach(button => {
    button.addEventListener('click', () => {
      const action = button.dataset.action;
      if (!urls || !itemDialog || !['rename', 'move', 'delete'].includes(action)) return;
      const form = document.getElementById('item-form');
      form.action = urls.dataset[action];
      document.getElementById('action-id').value = button.dataset.id;
      document.getElementById('action-kind').value = button.dataset.kind;
      document.getElementById('action-title').textContent = {
        rename: '重命名', move: '移动到文件夹', delete: '移至回收站'
      }[action];
      document.getElementById('action-note').textContent = button.dataset.name;
      const renameField = document.getElementById('rename-field');
      const moveField = document.getElementById('move-field');
      const renameInput = document.getElementById('rename-name');
      renameField.hidden = action !== 'rename';
      moveField.hidden = action !== 'move';
      renameInput.required = action === 'rename';
      renameInput.value = action === 'rename' ? button.dataset.name : '';
      document.getElementById('action-submit').textContent = action === 'delete' ? '确认删除' : '确认';
      document.getElementById('action-submit').classList.toggle('danger', action === 'delete');
      itemDialog.showModal();
      if (action === 'rename') renameInput.focus();
    });
  });
  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('click', e => {
      if (e.target === dialog) dialog.close();
    });
  });
  // Folder upload: webkitRelativePath is supported by Chrome, Edge and Safari.
  // Normal file upload works even with JS disabled; JS adds progress and hierarchy.
  const uploadForm = document.getElementById('upload-form');
  if (uploadForm) {
    const filePicker = document.getElementById('pick-files');
    const folderPicker = document.getElementById('pick-folder');
    [filePicker, folderPicker].forEach(input => input?.addEventListener('change', () => {
      if (input.files?.length) uploadForm.requestSubmit();
    }));
    uploadForm.addEventListener('submit', event => {
      if (!window.XMLHttpRequest || !window.FormData) return;
      event.preventDefault();
      const uploads = [...filePicker.files, ...folderPicker.files];
      if (!uploads.length) return;
      if (uploads.length > 30) { alert('单次最多上传30个文件，请分批上传。'); return; }
      const formData = new FormData(uploadForm);
      uploads.forEach(file => formData.append('paths', file.webkitRelativePath || file.name));
      const progress = document.getElementById('upload-progress');
      const status = document.getElementById('upload-status');
      const meter = document.getElementById('upload-meter');
      progress.hidden = false;
      status.textContent = `准备上传 ${uploads.length} 个文件…`;
      meter.style.width = '0%';
      const xhr = new XMLHttpRequest();
      xhr.open('POST', uploadForm.action);
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
      xhr.upload.addEventListener('progress', e => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100);
          meter.style.width = `${percent}%`;
          status.textContent = `正在上传 ${uploads.length} 个文件… ${percent}%`;
        }
      });
      xhr.onload = () => {
        let data;
        try { data = JSON.parse(xhr.responseText); } catch (_) { data = {ok:false, message:'服务器返回了异常响应。'}; }
        if (xhr.status >= 200 && xhr.status < 300 && data.ok) {
          status.textContent = '上传完成，正在更新文件列表…';
          location.reload();
        } else {
          status.textContent = data.message || '上传失败，请重试。';
          meter.style.width = '0%';
          filePicker.value = ''; folderPicker.value = '';
        }
      };
      xhr.onerror = () => { status.textContent = '网络连接中断，请检查后重试。'; };
      xhr.send(formData);
    });
  }
})();
